import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sponsored',
  templateUrl: './sponsored.component.html',
  styleUrls: ['./sponsored.component.css']
})
export class SponsoredComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
