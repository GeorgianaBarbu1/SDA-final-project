import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/service/auth.service';
import { UserModel } from 'src/app/user-model';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css'],
})
export class SignInComponent implements OnInit {
  constructor(private auth: AuthService, private router: Router) {}
  form = new FormGroup({
    nume_utilizator: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    parola: new FormControl('', [Validators.required, Validators.minLength(5)]),
    confirmare_parola: new FormControl('', [
      Validators.required,
      Validators.minLength(5),
    ]),
  });

  ngOnInit(): void {}

  onSubmit() {
    const submitValue = this.form.value;
    delete submitValue['confirmare_parola'];
    this.auth.requestRegistration(submitValue).subscribe(() => {
      this.router.navigate(['/login']);
    });
  }

  checkPassword() {
    if (
      this.form.controls.parola.value !== '' &&
      this.form.controls.confirmare_parola.value !== '' &&
      this.form.controls.parola.value ===
        this.form.controls.confirmare_parola.value &&
      this.form.valid
    ) {
      return true;
    }
    return false;
  }
}
