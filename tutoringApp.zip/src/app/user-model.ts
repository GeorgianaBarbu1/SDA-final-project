export interface UserModel {
  nume_utilizator: string;
  email: string;
  parola: string;
  id: number;
}

export interface UserLogin {
  email: string;
  parola: string;
}
