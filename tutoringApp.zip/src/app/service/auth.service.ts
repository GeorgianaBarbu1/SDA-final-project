import { HttpClient } from '@angular/common/http';
import { Inject, Injectable, InjectionToken } from '@angular/core';
import { UserLogin, UserModel } from '../user-model';
import { map } from 'rxjs/operators';
import { StorageService } from 'ngx-webstorage-service';
export const USER_SERVICE_STORAGE = new InjectionToken<StorageService>(
  'USER_SERVICE_STORAGE'
);

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  url = 'http://localhost:3000/';
  constructor(
    private http: HttpClient,
    @Inject(USER_SERVICE_STORAGE)
    private storage: StorageService
  ) {}

  getRandomId() {
    return Math.floor(Math.random() * 1000 + 1);
  }
  requestRegistration(submitUser: UserModel) {
    console.log('Ceva nu merge');
    return this.http.post(this.url + 'utilizatori', {
      ...submitUser,
      id: this.getRandomId().toString() + Date.now(),
    });
  }

  login(loggedUser: UserLogin) {
    return this.http.get<UserModel[]>(this.url + 'utilizatori').pipe(
      map((res) => {
        const foundUser = res.filter(
          (user) =>
            loggedUser.email === user.email && loggedUser.parola === user.parola
        );
        return foundUser[0];
      })
    );
  }

  public setToken(code: string, token: string): void {
    this.storage.set(code, token);
  }

  public getToken(code: string) {
    return this.storage.get(code) || null;
  }
}
