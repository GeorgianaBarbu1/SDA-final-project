import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TutoringService } from 'src/app/service/tutoringService';
import { Tutoring } from 'src/app/tutoring';

@Component({
  selector: 'app-filtered-subjects',
  templateUrl: './filtered-subjects.component.html',
  styleUrls: ['./filtered-subjects.component.css'],
})
export class FilteredSubjectsComponent implements OnInit {
  filterSubjects: Tutoring[] = [];
  keyFilter: string = '';
  constructor(
    private tutoringService: TutoringService,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    //imi iau din routa key-ul=>adica materia (eg. matematica, romana)
    this.keyFilter = this.route.snapshot.params['key'];
    this.tutoringService.getAllSubjects().subscribe((res) => {
      this.filterSubjects = res.filter((item) => item.key === this.keyFilter);
    });

    console.log(this.filterSubjects);
  }
}
