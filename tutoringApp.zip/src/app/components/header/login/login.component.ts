import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StorageService } from 'ngx-webstorage-service';

import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  constructor(private service: AuthService, private router: Router) {}
  form = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    parola: new FormControl('', [Validators.required, Validators.minLength(5)]),
  });

  ngOnInit(): void {}

  submitUser() {
    this.service.login(this.form.value).subscribe((data) => {
      if (data) {
        this.service.setToken('ID', data.id.toString());
        this.service.setToken('NUME_UTILIZATOR', data.nume_utilizator);
        location.reload();
        this.router.navigate(['/meditatii']);
      } else {
        alert('User not found!');
      }
    });
  }
}
