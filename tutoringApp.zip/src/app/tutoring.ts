export interface Tutoring {
  id: number;
  nume: string;
  materie: string;
  pret: string;
  descriere: string;
  sponsorizat: boolean;
  img: string;
  key: string;
  detalii: string;
}
