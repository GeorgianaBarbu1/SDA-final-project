import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { FilteredSubjectsComponent } from './components/filtered-subjects/filtered-subjects.component';
import { ContactUsComponent } from './components/footer/contact-us/contact-us.component';
import { FooterComponent } from './components/footer/footer.component';
import { PrivacyPolicyComponent } from './components/footer/privacy-policy/privacy-policy.component';
import { TermsAndConditionsComponent } from './components/footer/terms-and-conditions/terms-and-conditions.component';
import { LoginComponent } from './components/header/login/login.component';
import { NewAddComponent } from './components/header/new-add/new-add.component';
import { SignInComponent } from './components/header/sign-in/sign-in.component';
import { LogOutComponent } from './components/log-out/log-out.component';
import { MainComponent } from './components/main/main.component';

export const routes: Routes = [
  { path: '', redirectTo: '/meditatii', pathMatch: 'full' },
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: 'new-add',
    component: NewAddComponent,
  },
  {
    path: 'sign-in',
    component: SignInComponent,
  },
  {
    path: 'meditatii/:key',
    component: FilteredSubjectsComponent,
  },
  {
    path: 'meditatii',
    component: MainComponent,
  },
  {
    path: 'aboutUs',
    component: AboutUsComponent,
  },
  {
    path: 'contact',
    component: ContactUsComponent,
  },

  {
    path: 'privacy-policy',
    component: PrivacyPolicyComponent,
  },
  {
    path: 'terms-and-conditions',
    component: TermsAndConditionsComponent,
  },
  {
    path: 'logout',
    component: LogOutComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
