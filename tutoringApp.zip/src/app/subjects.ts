export interface Subjects {
  titlu: string;
  url: string;
  key_materie: string;
}
