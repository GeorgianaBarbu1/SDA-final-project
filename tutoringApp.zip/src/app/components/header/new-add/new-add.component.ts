import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TutoringService } from 'src/app/service/tutoringService';
import { Subjects } from 'src/app/subjects';

@Component({
  selector: 'app-new-add',
  templateUrl: './new-add.component.html',
  styleUrls: ['./new-add.component.css'],
})
export class NewAddComponent implements OnInit {
  constructor(private tutoringService: TutoringService) {}
  form = new FormGroup({
    nume: new FormControl('', Validators.required),
    materie: new FormControl('', Validators.required),
    pret: new FormControl('', Validators.required),
    descriere: new FormControl('', Validators.required),
    detalii: new FormControl('', Validators.required),
    img: new FormControl('', Validators.required),
    key: new FormControl('', Validators.required),
  });
  subjectsData: Subjects[] = [];
  ngOnInit(): void {
    this.tutoringService.getSubjects().subscribe((data: Subjects[]) => {
      this.subjectsData = data;
      console.log('Subjects data loaded: ' + this.subjectsData);
    });
  }
  localUrl = '';
  key = '';
  fileEvent(fileInput: any) {
    const reader = new FileReader();
    if (fileInput.target.files && fileInput.target.files[0]) {
      reader.onload = (event: any) => {
        this.localUrl = event.target.result;
        this.form.controls.img.setValue(this.localUrl);
      };
      reader.readAsDataURL(fileInput.target.files[0]);
    }
  }

  submitForm() {
    console.log(this.form.value);
  }
}
