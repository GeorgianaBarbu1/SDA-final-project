import { Component, OnInit, EventEmitter } from '@angular/core';
import { Subjects } from 'src/app/subjects';
import { TutoringService } from 'src/app/service/tutoringService';
import { Router } from '@angular/router';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css'],
})
export class MainComponent implements OnInit {
  subjectsData: Subjects[] = [];
  constructor(
    private tutoringService: TutoringService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.readAllSubjects();
  }
  readAllSubjects() {
    return this.tutoringService.getSubjects().subscribe((data: Subjects[]) => {
      this.subjectsData = data;
      console.log('Subjects data loaded: ' + this.subjectsData);
    });
  }

  handleSubjectEvent(subject: string) {
    this.router.navigate(['/meditatii/' + subject]);
  }
}
