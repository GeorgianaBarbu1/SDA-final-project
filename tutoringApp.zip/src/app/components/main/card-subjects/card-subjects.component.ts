import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-card-subjects',
  templateUrl: './card-subjects.component.html',
  styleUrls: ['./card-subjects.component.css'],
})
export class CardSubjectsComponent implements OnInit {
  @Input() imgUrl: string = '';
  @Input() title: string = '';
  @Output() clickEvent = new EventEmitter();
  constructor() {}
  //functia care emite evantul
  ngOnInit(): void {}
  handleClickEvent() {
    this.clickEvent.emit('Click event');
  }
}
