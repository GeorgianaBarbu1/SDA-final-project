import { Component, Input, OnInit } from '@angular/core';
import { Tutoring } from 'src/app/tutoring';

@Component({
  selector: 'app-tutoring-card',
  templateUrl: './tutoring-card.component.html',
  styleUrls: ['./tutoring-card.component.css'],
})
export class TutoringCardComponent implements OnInit {
  @Input() selectedTutoring: Tutoring = {} as Tutoring;
  constructor() {}

  ngOnInit(): void {}
}
