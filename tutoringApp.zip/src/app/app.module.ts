import { NgModule } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { NewAddComponent } from './components/header/new-add/new-add.component';
import { LoginComponent } from './components/header/login/login.component';
import { SignInComponent } from './components/header/sign-in/sign-in.component';
import { MainComponent } from './components/main/main.component';
import { SponsoredComponent } from './components/main/sponsored/sponsored.component';
import { FooterComponent } from './components/footer/footer.component';
import { ContactUsComponent } from './components/footer/contact-us/contact-us.component';
import { PrivacyPolicyComponent } from './components/footer/privacy-policy/privacy-policy.component';
import { TermsAndConditionsComponent } from './components/footer/terms-and-conditions/terms-and-conditions.component';
import { ReactiveFormsModule } from '@angular/forms';
import { CardSubjectsComponent } from './components/main/card-subjects/card-subjects.component';
import { FilteredSubjectsComponent } from './components/filtered-subjects/filtered-subjects.component';
import { TutoringCardComponent } from './components/tutoring-card/tutoring-card.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { USER_SERVICE_STORAGE } from './service/auth.service';
import { LOCAL_STORAGE } from 'ngx-webstorage-service';
import { LogOutComponent } from './components/log-out/log-out.component';
import { MatSelectModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    NewAddComponent,
    LoginComponent,
    SignInComponent,
    MainComponent,
    SponsoredComponent,
    FooterComponent,
    ContactUsComponent,
    PrivacyPolicyComponent,
    TermsAndConditionsComponent,
    CardSubjectsComponent,
    FilteredSubjectsComponent,
    TutoringCardComponent,
    AboutUsComponent,
    LogOutComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    HttpClientModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSelectModule,
    BrowserAnimationsModule,
  ],
  providers: [{ provide: USER_SERVICE_STORAGE, useExisting: LOCAL_STORAGE }],
  bootstrap: [AppComponent],
})
export class AppModule {}
