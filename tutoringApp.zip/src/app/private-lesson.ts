export interface PrivateLesson {
  id: number;
  nume: string;
  materie: string;
  pret: string;
  descriere: string;
  detalii: string;
  img: string;
  key: string;
}
