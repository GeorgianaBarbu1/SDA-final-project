import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Tutoring } from '../tutoring';
import { Subjects } from '../subjects';
import { PrivateLesson } from '../private-lesson';

@Injectable({
  providedIn: 'root',
})
export class TutoringService {
  url = 'http://localhost:3000/';
  constructor(private http: HttpClient) {}
  getMeditatieByMaterie(materie: string) {
    return this.http.get<Tutoring>(this.url + 'meditatii/' + materie);
  }

  getAllSubjects() {
    return this.http.get<Tutoring[]>(this.url + 'meditatii');
  }

  getSubjects() {
    return this.http.get<Subjects[]>(this.url + 'materii');
  }
  // functia pentru filtrare

  getFilteredSubjects(keyFilter: string): Tutoring[] | any {
    this.getAllSubjects().subscribe((res) => {
      const filterSubject = res.filter((item) => item.key === keyFilter);
      return filterSubject;
    });
  }
  getRandomId() {
    return Math.floor(Math.random() * 1000 + 1);
  }

  postSubject(subject: PrivateLesson) {
    return this.http.post(this.url, {
      ...subject,
      id: this.getRandomId().toString() + Date.now(),
    });
  }
}
